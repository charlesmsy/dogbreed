# breeddog/urls.py
from django.urls import path

from . import views

urlpatterns = [
    path('breed/', views.ListBreed.as_view()),
    path('breed/<int:pk>/', views.DetailBreed.as_view()),
    path('dog/', views.ListDog.as_view()),
    path('dog/<int:pk>/', views.DetailDog.as_view()),
]