# todos/serializers.py
from rest_framework import serializers
from .models import Breed
from .models import Dog

class BreedSerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            'id',
            'name',
            'size',
            'friendliness',
            'tainability',
            'sheddingamount',
            'exerciseneeds',
        )
        model = Breed
        
class DogSerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            'id',
            'name',
            'age',
            'breed',
            'gender',
            'color',
            'favoritefood',
            'favoritetoy',
        )
        model = Dog