from django.apps import AppConfig


class BreeddogConfig(AppConfig):
    name = 'breeddog'
