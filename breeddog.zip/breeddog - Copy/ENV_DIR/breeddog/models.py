# dogbreed/models.py
from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

class Breed(models.Model):
    name = models.CharField(max_length=200)
    size = models.CharField(max_length=20)
    friendliness = models.PositiveIntegerField(default=3, validators=[MinValueValidator(1), MaxValueValidator(5)])
    tainability = models.PositiveIntegerField(default=3, validators=[MinValueValidator(1), MaxValueValidator(5)])
    sheddingamount = models.PositiveIntegerField(default=3, validators=[MinValueValidator(1), MaxValueValidator(5)])
    exerciseneeds = models.PositiveIntegerField(default=3, validators=[MinValueValidator(1), MaxValueValidator(5)])

    def __str__(self):
        """A string representation of the model."""
        return self.name

class Dog(models.Model):
    name = models.CharField(max_length=200)
    age = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1), MaxValueValidator(100)])
    breed = models.ForeignKey(Breed, on_delete=models.CASCADE)
    gender = models.CharField(max_length=20)
    color = models.CharField(max_length=20)
    favoritefood = models.CharField(max_length=200)
    favoritetoy = models.CharField(max_length=200)

    def __str__(self):
        """A string representation of the model."""
        return self.name
        