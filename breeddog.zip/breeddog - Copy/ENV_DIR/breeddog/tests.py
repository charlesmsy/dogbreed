# breed/tests.py
from django.test import TestCase
from .models import Breed
from .models import Dog


class BreedModelTest(TestCase):

    @classmethod
    def setUpTestData(cls):
        Breed.objects.create(name='first breed')
        Breed.objects.create(size='Large')
        Breed.objects.create(friendliness=3)
        Breed.objects.create(tainability=3)
        Breed.objects.create(sheddingamount=3)
        Breed.objects.create(exerciseneeds=3)

    def test_name_content(self):
        breed = Breed.objects.get(id=1)
        expected_object_name = f'{breed.name}'
        self.assertEquals(expected_object_name, 'first breed')

    def test_size_content(self):
        breed = Breed.objects.get(id=2)
        expected_object_name = f'{breed.size}'
        self.assertEquals(expected_object_name, 'Large')